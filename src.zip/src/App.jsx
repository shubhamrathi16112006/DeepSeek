import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./App.css";

import Home from "./Home";
import About from "./About";
import Shop from "./Shop";
import Contact from "./Contact";
import AppLayout from "./AppLayout";
import ProtectedRoute from "./ProtectedRoute";
import Login from "./Login";
import Product from "./Product";

function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <ProtectedRoute />,
      children: [
        {
          element: <AppLayout />,
          children: [
            { index: true, element: <Home /> },
            { path: "About", element: <About /> },
            { path: "Shop", element: <Shop /> },
            { path: "Contact", element: <Contact /> },
            { path: "Product/:id", element: <Product /> },
          ],
        },
      ],
    },
    { path: "/Login", element: <Login /> },
  ]);

  return <RouterProvider router={router} />;
}

export default App;
