import React from 'react'

export default function About() {
  return (
    <>
    <h1>About</h1>
    <h2>This is About Page</h2>
    </>
  )
}
