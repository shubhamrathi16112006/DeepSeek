import React from 'react'

export default function About() {
  return (
    <>
    <h1>Contact</h1>
    <h2>This is Contact Page</h2>
    </>
  )
}
