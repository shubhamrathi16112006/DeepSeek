import movies from "./movies.json";
import MovieCard from "./Moviecard";
import "../css/Cardmodule.css";

export default function Shop() {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
      {movies.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  );
}
