import React from 'react'

export default function Footer() {
  return (
   <>
   <h1 style={{backgroundColor: "red"}}>Footer</h1>
   </>
  )
}
