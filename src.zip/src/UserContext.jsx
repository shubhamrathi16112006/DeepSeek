import React, { createContext, useContext, useEffect, useState } from "react";

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("Data")) || false
  );

  const login = (username, password) => {
    setUser({ username });
    return true;
  };

  useEffect(() => {
    localStorage.setItem("Data", JSON.stringify(user));
  }, [user]);

  return (
    <UserContext.Provider value={{ user, login, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
